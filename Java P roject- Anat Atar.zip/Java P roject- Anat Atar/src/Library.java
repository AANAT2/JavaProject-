import com.sun.org.apache.xpath.internal.operations.Bool;

import java.util.ArrayList;
import java.util.List;

public class Library {
    //defining variables
    private List<Shelf> shelves;
    private List<Reader> readers;

    //constractotr
    public Library() {
        this.shelves = new ArrayList<>();
        for (int i = 0; i <= 2; i++) {
            Shelf shelf = new Shelf();
            this.shelves.add(shelf);
        }
        this.readers = new ArrayList<>();
    }
    // creating getters

    public List<Shelf> getShelves() {
        return shelves;
    }

    public List<Reader> getReaders() {
        return readers;
    }

    public Boolean isTherePlaceForNewBook() {
        for (Shelf shelf : this.shelves) {
            if (shelf.getIsShelfFull() == false) {
// library is not full
                return true;
            }
        }
        // library is full
        return false;
    }

    // CHECHING FOR AN OPEN SHELF
    public void addNewBook(Book book) {
        for (Shelf shelf : this.shelves) {
            if (shelf.getIsShelfFull() == false) {
                shelf.addBook(book);
            }
        }
    }

    public void deleteBook(String title) {
        // looking for the title on all shelves
        for (Shelf shelf : this.shelves) {
            //looking for the title from list pf books on the shelf
            for (Book book : shelf.getBooks()) {
                //deleting the title from list of books on shelf and returning to main
                if (book.getTitle() == title) {
                    shelf.getBooks().remove(book);
                    return;
                }
            }
        }
    }

    //function for register reader
    public void registerReader(String name, int id) {
        Reader reader = new Reader(id, name);
        this.readers.add(reader);
    }

    //function for remove reader
    public void removeReader(String name) {
        for (Reader reader : this.readers) {
            // CHECHIMG ALL READERS
            if (reader.getName() == name) {
                this.readers.remove(reader);
            }
        }
    }

    //function for search author
    public List<String> searchByAuthor(String author) {
        List<String> bookTitles = new ArrayList<>();
        //chechking shelves
        for (Shelf shelf : this.shelves) {
            //looking for the author from list of books on the shelf
            for (Book book : shelf.getBooks()) {
                //checking if the authors book is thr author
                if (book.getAuthor() == author) {
                    //adding title to list titles
                    bookTitles.add(book.getTitle());
                }
            }
        }
        // returning list of titles to main
        return bookTitles;
    }
}

