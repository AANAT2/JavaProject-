import java.util.ArrayList;
import java.util.List;

public class Shelf {
    //defining variables
    private List<Book> books;
    private Boolean isShelfFull;

    //defining constractor for books as isShelfFull as false since it starts with 2 books (less than the maximun of 5)
    public Shelf() {
        this.books = new ArrayList<>();
        this.isShelfFull = false;
    }

    //defining getters
    public List<Book> getBooks() {
        return books;
    }

    public Boolean getIsShelfFull() {
        return isShelfFull;
    }

    //defining setter


    public void setShelfFull(Boolean shelfFull) {
        isShelfFull = shelfFull;
    }

    //creating function addBook
    public void addBook(Book book) {
        if (isShelfFull == true) {
            System.out.println("The shelf is full");
            return;
        }
        //adding a book to shelf it shelf is not full
        this.books.add(book);
        //checking if shelf is full (equals 5)
        if (books.size() == 5) {
            isShelfFull = true;
        }
        //function for replaceBooks
    }
    public void replaceBooks (int index1, int index2){
        Book[] books= new Book[5];
        int counter= 0;
        for (Book book:this.books){
            books [counter]=book;
        }
        // eliminating invalid indexes
        if (index1<0 || index1>5 || index2<0 || index2>5 || index2<=index1){
            System.out.println("error invalid indexes");
            return;
        }
        //creating variable for temporary location for book
        Book temporaryBook = books[index1];
        //overing index1 with index2
        books[index1]= books[index2];
        books[index2] = temporaryBook;
        // creating updated book list on shelf
        List<Book> upDatedBookList= new ArrayList<>();
        // putting books in list
        for (int i=0; i<books.length; i++){
            upDatedBookList.add(books[i]);
        }
        // updating the maim list of books on shelf
        this.books= upDatedBookList;
    }
}
