import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //creating a library object
        Library library = new Library();
        Scanner scan = new Scanner(System.in);
        //running on all shelves in libraryanat
        for (Shelf shelf : library.getShelves()) {
            for (int i = 0; i < 2; i++) {
                //caliing for creation of new book
                Book book = creatingANewBook();
                //adding thr book to shelf
                shelf.getBooks().add(book);
            }
        }
//difining users choice from menu
        int choice;
        List<String> titleBookList = new ArrayList<>();
        do {
            System.out.println("• - “For adding a book - Press 1”.\n" +
                    "• - “For deleting a book - Press 2”.\n" +
                    "• - “For registering a new reader - Press 3”.\n" +
                    "• - “For removing a reader - Press 4”.\n" +
                    "• - “For searching books by author – Press 5.”\n" +
                    "• - “For exit – Press 6”.");
            choice = scan.nextInt();
            switch (choice) {
                case 1:
                    Book book = creatingANewBook();
                    library.addNewBook(book);
                    System.out.println("Book added");
                    break;
                case 2:
                    System.out.println(" enter title of book for deletion");
                    String title = scan.nextLine();
                    library.deleteBook(title);
                    System.out.println("Book deleted");
                    break;

                case 3:
                    System.out.println("Please enter a name : ");
                    String name = scan.nextLine();
                    System.out.println("Please enter an id : ");
                    int id = scan.nextInt();
                    library.registerReader(name, id);
                    System.out.println("Book registered");
                    break;
                case 4:
                    System.out.println("Please enter a name : ");
                    String nameToDelete = scan.nextLine();
                    library.removeReader(nameToDelete);
                    System.out.println("Reader removed");
                    break;
                case 5:
                    System.out.println("Please enter a name : ");
                    String author = scan.nextLine();
                    titleBookList = library.searchByAuthor(author);
                    break;


            }
        } while (choice != 6);
    }

    // creating new book
    public static Book creatingANewBook() {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the title of the book : ");
        String title = scan.nextLine();
        System.out.println("Enter the author of the book : ");
        String author = scan.nextLine();
        System.out.println("Enter the number of pages of the book : ");
        int numOfPages = scan.nextInt();
        Book book = new Book(author, title, numOfPages);
        return book;
    }
}
