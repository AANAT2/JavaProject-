import java.util.ArrayList;
import java.util.List;

public class Reader {
    //defining variables
    private int id;
    private String name;
    private List<String> books;
    //defining constractor that adds a book to the readers list of books
    public Reader(int id, String name){
        this.id = id;
        this.name = name;
        this.books = new ArrayList<>();
    }
    //function for reading a book
    public void readBook(String title){
        books.add(title);
    }
    //defining getters
    public int getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public List<String> getBooks(){
        return books;
    }
    //defining setter
    public void setName(String name){
        this.name = name;
    }
}
